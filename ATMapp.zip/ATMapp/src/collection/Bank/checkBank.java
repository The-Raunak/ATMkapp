package collection.Bank;

public class checkBank {
    String IFSC1 = "Bank10002";
    String IFSC2 = "Bank20002";
    String IFSC3 = "Bank30002";

    Bank1 call = new Bank1();
    Bank2 call1 = new Bank2();
    Bank3 call2 = new Bank3();
    public void callBank(String IFSC,long acc_No,double amt){
        if(IFSC.equals(IFSC1)){
            call.checkAccountNumber(acc_No,amt);
        }else if(IFSC.equals(IFSC2)){
            call1.checkAccountNumber(acc_No,amt);
        }else if(IFSC.equals(IFSC3)){
            call2.checkAccountNumber(acc_No,amt);
        }else{
            System.out.println("Bank doesn't exist");
        }
        return;
    }
}
