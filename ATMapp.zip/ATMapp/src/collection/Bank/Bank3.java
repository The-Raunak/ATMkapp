package collection.Bank;

public class Bank3 {
     long acc_No1 = 1122334455;
     long acc_No2 = 1234512345;
     long acc_No3 = 1234567890;
     void cust1(double amt){
        double balance = 20000.0;
        System.out.println("Current balance is = "+balance+" transferring amount = "+amt);
        balance += amt;
        System.out.println("Available balance = "+balance);
        return;
    } void cust2(double amt){
        double balance = 10000.0;
        System.out.println("Current balance is = "+balance+" transferring amount = "+amt);
        balance += amt;
        System.out.println("Available balance = "+balance);
        return;
    } void cust3(double amt){
        double balance = 30000.0;
        System.out.println("Current balance is = "+balance+" transferring amount = "+amt);
        balance += amt;
        System.out.println("Available balance = "+balance);
        return;
    }
    public  void checkAccountNumber(long acc_No,double amt){
        if(acc_No == acc_No1){
            cust1(amt);
        }else if(acc_No == acc_No2){
            cust2(amt);
        }else if(acc_No == acc_No3){
            cust3(amt);
        }else{
            System.out.println("Account doesn't exist");
        }
        return;
    }
}
