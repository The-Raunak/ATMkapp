import collection.Bank.checkBank;

import java.util.Scanner;

public class BankCustomer {
    String customerName;
    double balance = 20000.0,amt;
    long acc_No;
    String IFSCcode;
    checkBank transf = new checkBank();
    Scanner sc = new Scanner(System.in);
    void debit(){
        System.out.println("Enter the amount you wanna debit = ");
        amt = sc.nextDouble();
        if(amt<=balance){
            System.out.println("successfully debited "+amt+" from your bank");
            balance -= amt;
            System.out.println("Available balance is = "+balance);
        }
        else{
            System.out.println("Insufficient balance");
        }
    }
    void transfer(){
        System.out.println("Enter the IFSC code of the bank = ");
        IFSCcode = sc.nextLine();
        // we can create a package of banks and compare them as we did for the customers using ifsc code
        System.out.println("Enter the account number = ");
        acc_No = sc.nextLong();
        System.out.println("Enter the amount you wanna transfer = ");
        amt = sc.nextDouble();
        transf.callBank(IFSCcode,acc_No,amt);
    }
    public void options(char choice){
        switch (choice){
            case 'd':
                debit();
                return;
            case 't':
                transfer();
                return;
            case 'e':
                System.exit(1);
        }
    }
}
