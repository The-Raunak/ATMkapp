public class ATMPin {
    public boolean verifyPinNumber(){

        java.util.Scanner sc=new java.util.Scanner(System.in);
        System.out.println("please enter valid atm pin number!!!");
        boolean b=false;
        int   pin=sc.nextInt();

        switch(pin){

            case 1111:
            case 2222:
            case 3333:
            case 4444:

                b=true ;
                break;

        }
        return b;
    }
}

